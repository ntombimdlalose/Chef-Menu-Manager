import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';

import { Dropdown } from 
'react-native-element-dropdown';

export default function App() { 
  const [course, setCourse] = 
  useState('');
  const [dishName, setDishName] =
   useState('');
const [description, setDescription] =
 useState('');
const [price, setPrice] = useState('');
const [menuItems, setMenuItems] =useState([]);
 const addMenuItem = () => {
  if (
    dishName.trim() === '' ||
    description.trim() === '' ||
    !course ||
    price.trim() === ''
  ) {
    alert('Please complete all fields.');
    return;
  }

  const newItem = {
    id: Date.now().toString(),
    dishName,
    description,
    course,
    price,
  };

  setMenuItems([...menuItems, newItem]);

  setDishName('');
  setDescription('');
  setCourse('');
  setPrice('');
};



  const courseOptions = [
  { label: 'Starter', value: 'Starter' },
  { label: 'Main Course', value: 'Main Course' },
  { label: 'Dessert', value: 'Dessert' },
];

return (

    <View style={styles.container}>
    <Text style={styles.title}>Chef Menu Manager</Text>
      
    <TextInput
style={styles.input}
  placeholder="Dish Name"
  value={dishName}
  onChangeText={setDishName}
/>

<TextInput
  style={styles.input}
  placeholder="Description"
  value={description}
  onChangeText={setDescription}
/>

<Text>Course</Text>
<Dropdown
style={styles.input}
  data={courseOptions}
  labelField="label"
  valueField="value"
  placeholder="Select Course"
  value={course}
  onChange={(item) => 
  setCourse(item.value)}
/>

<TextInput
style={styles.input}
  placeholder="Price"
  value={price}
  onChangeText={setPrice}
/>

 <TouchableOpacity
  style={styles.button}
  onPress={addMenuItem}
>
  <Text style={styles.buttonText}>Add Menu Item</Text>
</TouchableOpacity>
<Text style={styles.menuTitle}>Menu Items</Text>

<FlatList
  style={styles.list}
  data={menuItems}
  keyExtractor={(item) => item.id}
  renderItem={({ item }) => (
    <View>
      <Text style={styles.menuText}>Dish: {item.dishName}</Text>
      <Text style={styles.menuText}>Description: {item.description}</Text>
      <Text style={styles.menuText}>Course: {item.course}</Text>
      <Text style={styles.menuText}>Price: {item.price}</Text>
    </View>
  )}
/>
</View>




  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    paddingTop: 12,
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  
  },

  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 35,
  },
  
  label: {
  fontSize: 18,
  marginBottom: 8,
  textAlign: 'center',
},



  input: {
    width: '90%',
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
    fontSize: 20,
    backgroundColor: 'white',
  },
  button: {
  width: '90%',
  backgroundColor: '#999',
  padding: 12,
  borderRadius: 8,
  marginBottom: 20,
  alignItems: 'center',
},
buttonText: {
  fontSize:18,
  fontWeight: 'bold'
},

menuTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  marginBottom: 10,
},

menuText: {
  fontSize: 22,
  marginBottom: 5,
},
list:{
  width: '90%',
  height: 250,

}
});